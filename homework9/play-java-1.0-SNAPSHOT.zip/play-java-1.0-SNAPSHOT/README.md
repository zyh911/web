Java MVC Web app with the Play! framework.

Version: activator-dist-1.3.7
IDE: IntelliJ 14.X
OS: Mac OS X 10.11.1
Java Version: JDK 1.8.X
